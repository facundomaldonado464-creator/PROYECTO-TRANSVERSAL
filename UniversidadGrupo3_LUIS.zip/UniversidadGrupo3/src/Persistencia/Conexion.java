/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3306/universidad_db";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Coloca tu contraseña de MySQL/phpMyAdmin si tienes
    private static Connection connection;

    private Conexion() {}

    public static Connection getConexion() {
        if (connection == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Error al cargar los drivers: " + e.getMessage());
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al conectarse a la base de datos: " + e.getMessage());
            }
        }
        return connection;
    }
}


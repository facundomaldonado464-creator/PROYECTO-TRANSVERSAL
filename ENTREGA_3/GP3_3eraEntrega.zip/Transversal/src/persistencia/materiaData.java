/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import entidades.Materia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class materiaData {
    
public void insertar(Materia m) throws SQLException {

        String sql = "INSERT INTO materia (nombre, anio, estado) VALUES (?,?,?)";
        try (Connection con = miConexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getNombre());
            ps.setInt(2, m.getAnio());
            ps.setBoolean(3, m.isActivo());
            ps.executeUpdate();
        }
    }
    
    public void borrar(int idMateria) throws SQLException {
        String sql = "DELETE FROM materia WHERE idMateria=?";
        try (Connection con = miConexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, idMateria);
            ps.executeUpdate();
        }
    }
    
    public void bajaLogica(int idMateria) throws SQLException {
        String sql = "UPDATE materia SET estado=0 WHERE idMateria=?";
        try (Connection con = miConexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, idMateria);
            ps.executeUpdate();
        }
    }
    
    public void altaLogica(int idMateria) throws SQLException {
        String sql = "UPDATE materia SET estado=1 WHERE idMateria=?";
        try (Connection con = miConexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMateria);
            ps.executeUpdate();
        }
    }
    
    public Materia buscar(int idMateria) throws SQLException {
        String sql = "SELECT * FROM materia WHERE idMateria=?";
        try (Connection con = miConexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMateria);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Materia mat = new Materia();
                    mat.setIdMateria(rs.getInt("idMateria"));
                    mat.setNombre(rs.getString("nombre"));
                    mat.setAnio(rs.getInt("anio"));
                    mat.setActivo(rs.getBoolean("estado")); 
                    return mat;
                }
            }
        }
    return null;
    }
    
    public List<Materia> listarTodas() throws SQLException {
        List<Materia> lista = new ArrayList<>();
        String sql = "SELECT * FROM materia";
        try (Connection con = miConexion.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Materia mat = new Materia();
                mat.setIdMateria(rs.getInt("idMateria"));
                mat.setNombre(rs.getString("nombre"));
                // Recuperamos el anio para la lista
                mat.setAnio(rs.getInt("anio"));
                mat.setActivo(rs.getBoolean("estado"));
                lista.add(mat);
            }
        }
        return lista;
    }

    public void actualizar(Materia m) throws SQLException {
        String sql = "UPDATE materia SET nombre=?, anio=?, estado=? WHERE idMateria=?";

        try (Connection con = miConexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, m.getNombre());
            ps.setInt(2, m.getAnio());
            ps.setBoolean(3, m.isActivo());
            ps.setInt(4, m.getIdMateria());

            int filas = ps.executeUpdate();

            if (filas == 0) {
                throw new SQLException("No existe una materia con ese ID.");
            }
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package persistencia;

import entidades.Cursada;
import entidades.Materia; 
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import entidades.Alumno;




/**
 *
 * @author facun
 */
public class InscripcionData {
    
    private Connection con=null;
    
    public InscripcionData(){
    
        con=miConexion.getConnection();
        
    }
    
    public static void main(String[] args) {
      
        // TODO code application logic here    
    }
    
    
    public void guardarInscripcion(Cursada insc) {
        String sql = "INSERT INTO cursada (idAlumno, idMateria, nota) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps=con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1,insc.getIdAlumno());
            ps.setInt(2,insc.getIdMateria());
            ps.setInt(3,insc.getNota()); 
            ps.executeUpdate();
            ResultSet rs=ps.getGeneratedKeys();
            if (rs.next()) {
                insc.setIdCursada(rs.getInt(1));
                JOptionPane.showMessageDialog(null,"registrada");
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Error"+ex.getMessage());
        }
    }
    
    
    
    
    
    public List<Materia> obtenerMateriasCursadas(int idAlumno) {
        List<Materia> materias=new ArrayList<>();
        String sql="SELECT materia.idMateria, nombre, estado FROM cursada "
                   + "JOIN materia ON cursada.idMateria = materia.idMateria "
                   + "WHERE cursada.idAlumno = ?";
        
        try {
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setInt(1, idAlumno);
            ResultSet rs=ps.executeQuery();
            while (rs.next()) {
                Materia materia=new Materia();
                materia.setIdMateria(rs.getInt("idMateria"));
                materia.setNombre(rs.getString("nombre"));
                materia.setActivo(rs.getBoolean("estado")); 
                materias.add(materia);
            }
            ps.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Error" + ex.getMessage());
        }
        return materias;
    }
    
    
    
    public List<Materia>obtenerMateriasNOCursadas(int idAlumno) {
        List<Materia> materias=new ArrayList<>();
        
        String sql = "SELECT * FROM materia WHERE estado = 1 AND idMateria NOT IN "
                   + "(SELECT idMateria FROM cursada WHERE idAlumno = ?)";
        
        try {
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setInt(1,idAlumno);
            ResultSet rs=ps.executeQuery();
            
            while (rs.next()){
                Materia materia=new Materia();
                materia.setIdMateria(rs.getInt("idMateria"));
                materia.setNombre(rs.getString("nombre"));
                materia.setActivo(rs.getBoolean("estado")); 
                materias.add(materia);
            }
            ps.close();
            
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,"Error"+ex.getMessage());
        }
        return materias;
    }
    
    
    
    public void borrarInscripcionMateriaAlumno(int idAlumno,int idMateria) {
        String sql = "DELETE FROM cursada WHERE idAlumno = ? AND idMateria = ?";
        
        try {
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setInt(1,idAlumno);
            ps.setInt(2,idMateria);
            
            int filasAfectadas=ps.executeUpdate();
            if (filasAfectadas>0){
                JOptionPane.showMessageDialog(null,"anulada con exito.");
            }
            ps.close();
            
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,"Error"+ex.getMessage());
        }
    }
    
    
    //actualiza
    
   public void actualizarNota(int idAlumno,int idMateria,int nota) {
        String sql="UPDATE cursada SET nota = ? WHERE idAlumno = ? AND idMateria = ?";
        
        try {
            con = miConexion.getConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setInt(1,nota);
            ps.setInt(2,idAlumno);
            ps.setInt(3,idMateria);
            
            int filasAfectadas=ps.executeUpdate();
            if (filasAfectadas>0){
                JOptionPane.showMessageDialog(null,"Nota actualizada");
            }
            ps.close();
            
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,"Error"+ex.getMessage());
        }
    } 
    
    
   public List<Cursada> obtenerInscripcionesAlumno(int idAlumno) {
    List<Cursada> cursadas = new ArrayList<>();
    String sql = "SELECT * FROM cursada WHERE idAlumno = ?";
    
    try (Connection conexionLocal = miConexion.getConnection();
         PreparedStatement ps = conexionLocal.prepareStatement(sql)) {
        
        ps.setInt(1, idAlumno);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()){
                Cursada cursada = new Cursada();
                cursada.setIdCursada(rs.getInt("idCursada"));
                cursada.setIdAlumno(rs.getInt("idAlumno"));
                cursada.setIdMateria(rs.getInt("idMateria"));
                cursada.setNota(rs.getInt("nota"));
                cursadas.add(cursada);
            }
        }
    } catch (SQLException ex){
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
    }
    return cursadas;
}
   
   
public List<Alumno> obtenerAlumnosXMateria(int idMateria) {
    List<Alumno> alumnos = new ArrayList<>();
    String sql = "SELECT a.idAlumno, a.dni, a.nombre, a.fechaNac, a.activo "
               + "FROM alumno a JOIN cursada c ON a.idAlumno=c.idAlumno "
               + "WHERE c.idMateria=?";
    
    try (Connection conLocal = java.sql.DriverManager.getConnection("jdbc:mariadb://localhost:3306/universidad", "root", "");
         PreparedStatement ps = conLocal.prepareStatement(sql)) {
        
        ps.setInt(1, idMateria);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()){
                Alumno alumno = new Alumno();
                alumno.setId(rs.getInt("idAlumno"));
                alumno.setDni(rs.getInt("dni"));
                alumno.setNombre(rs.getString("nombre"));
                alumno.setFecNac(rs.getDate("fechaNac").toLocalDate());
                alumno.setActivo(rs.getBoolean("activo"));
                alumnos.add(alumno);
            }
        }
    } catch (SQLException ex){
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
    }
    return alumnos;
}
   
   
}

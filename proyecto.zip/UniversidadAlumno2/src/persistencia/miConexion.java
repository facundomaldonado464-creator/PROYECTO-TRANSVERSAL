
package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class miConexion {
    
    private String url= "jdbc:mariadb://localhost:3306/universidad";
    private String usuario="root";
    private String password="";
    
    private static Connection conexion=null;
    
    public Connection buscarConexion(){
        if(conexion==null){
        
        try{
        
        Class.forName("org.mariadb.jdbc.Driver");
        conexion=DriverManager.getConnection(url,usuario,password);
        }
        catch (SQLException | ClassNotFoundException ex){
            System.out.println("No se pudo conectar");
        }
        
        
        }
    return conexion;
    
    }
    
}
